﻿using System;

namespace Kocsistem.RabbitMQ.Stock.Application.Models
{
    public class StockSalesQuantity
    {
        public Guid Id { get; set; }
        public int Quantity { get; set; }
    }
}
